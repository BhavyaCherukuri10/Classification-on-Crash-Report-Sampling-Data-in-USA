# Classicication-project-on-CRSS-Data
Logistic regression and Random forest. Focuses on modeling and data engineering techniques.

Download the code file Link: https://www.nhtsa.gov/file-downloads?p=nhtsa/downloads/CRSS/
For years 2019,2020,2021. Save them with names: CRSS2019CSV, CRSS2020CSV, CRSS2021CSV
